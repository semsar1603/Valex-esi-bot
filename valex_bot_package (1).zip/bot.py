
import time
import requests

API_KEY = '476df49e97da4f398e93205a47467039'
TOKEN = '7724128489:AAFG8XHgakB4EUlL7qPxQNst-CybCGp6lrk'
CHAT_ID = '2041894604'

def get_rsi(symbol):
    url = f"https://api.twelvedata.com/rsi?symbol={symbol}&interval=1min&time_period=14&apikey={API_KEY}"
    try:
        response = requests.get(url)
        data = response.json()
        rsi_value = float(data['values'][0]['rsi'])
        return round(rsi_value, 2)
    except Exception as e:
        print(f"❌ خطأ في جلب RSI: {e}")
        return None

def send_signal(symbol_name, rsi):
    if rsi is None:
        msg = f"⚠️ تعذر الحصول على RSI لزوج {symbol_name}"
    elif rsi < 30:
        msg = f"📊 الزوج: {symbol_name}
🔼 إشارة: شراء (RSI = {rsi})"
    elif rsi > 70:
        msg = f"📊 الزوج: {symbol_name}
🔽 إشارة: بيع (RSI = {rsi})"
    else:
        msg = f"❌ الزوج: {symbol_name} لا توجد فرصة واضحة (RSI = {rsi})"

    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    data = {"chat_id": CHAT_ID, "text": msg}
    try:
        requests.post(url, data=data)
    except Exception as e:
        print(f"🚫 فشل في الإرسال إلى تيليغرام: {e}")

symbols = {
    "EUR/USD": "EUR/USD",
    "GBP/JPY": "GBP/JPY"
}

while True:
    for name, code in symbols.items():
        print(f"🔍 معالجة الزوج: {name}")
        rsi = get_rsi(code)
        send_signal(name, rsi)
    print("⏳ ننتظر 5 دقائق قبل الجولة القادمة...")
    time.sleep(300)
